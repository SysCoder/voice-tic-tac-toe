
var ActionFunctionTester = require('./action-function-tester');

var fs = require('fs');

console.log(process.argv[2]);
if (process.argv[2] === undefined) {
  console.log("Please add interaction JSON file as a command line argument.");
}

var testsInJSON = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));

var VoiceCount = require(testsInJSON.fileName);

runTests(VoiceCount);

function runTests (loadedModule) {
  for (let i = 0;i < testsInJSON.tests.length;i++) {
    let test = testsInJSON.tests[i];
    console.log("Starting test: " + test.name)
    let actionFunctionTester = new ActionFunctionTester(loadedModule[testsInJSON.methodName]);
    // console.log(JSON.stringify(test));

    for (let j = 0;j < test.interactions.length;j++) {
      let interaction = test.interactions[j];
      let responseText = actionFunctionTester.makeUtterance(interaction.utterance);
      console.log('\x1b[33m%s\x1b[0m%s', "User: ", interaction.utterance);
      if (responseText === interaction.response) {
        console.log('\x1b[36m%s\x1b[0m%s', "Voice App: ", interaction.response);
        console.log('\x1b[32m%s\x1b[0m', 'PASSED');
      } else {
        console.log('\x1b[35m%s\x1b[0m', 'EXPECTED');
        console.log('\x1b[36m%s\x1b[0m%s', "Voice App: ", interaction.response);
        console.log('\x1b[35m%s\x1b[0m', 'FOUND');
        console.log('\x1b[36m%s\x1b[0m%s', "Voice App: ", responseText);
        console.log('\x1b[31m%s\x1b[0m', 'FAILED');
      }
    }
  }
}
