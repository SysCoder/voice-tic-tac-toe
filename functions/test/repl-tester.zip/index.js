var moduleUnderTest = require('../index');

var ActionFunctionTester = require('./action-function-tester');

var actionFunctionTester = new ActionFunctionTester(moduleUnderTest.voiceTicTacToe);
console.log(actionFunctionTester.makeUtterance("Hey this works!"));
console.log(actionFunctionTester.makeUtterance("Hello World"));
